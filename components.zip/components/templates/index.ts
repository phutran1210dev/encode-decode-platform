// Templates - Page layouts and structures
export { HeaderSection } from './header-section';
export { MainContent } from './main-content';